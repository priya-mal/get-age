def main():
    num = int(input('To know your age in 2020, enter your birth year \n'))
    age=2020-num
    print("your age is {}".format(age))

if __name__ == '__main__':
    main()
