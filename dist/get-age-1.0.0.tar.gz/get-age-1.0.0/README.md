#Age 2020
It takes an integer as an input and prints it square.

##Installation
pip install get-age

##How to use it?
Open terminal and type age and then input the integer (your birth year)

License
© 2020 Priya_mal

This repository is licensed under the MIT license. See LICENSE for details.